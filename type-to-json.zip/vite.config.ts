import { defineConfig } from 'vite'
import { resolve } from 'path'

export default defineConfig({
  build: {
    lib: {
      entry: {
        index: resolve(__dirname, 'src/index.ts'),
        cli: resolve(__dirname, 'src/cli.ts'),
      },
      formats: ['es'],
      fileName: (_format, entryName) => `${entryName}.js`,
    },
    rollupOptions: {
      external: [
        'typescript',
        'chalk',
        'ora',
        'commander',
        'path',
        'fs',
        'fs/promises',
        'url',
        'os',
        'node:path',
        'node:fs',
        'node:fs/promises',
        'node:url',
        'node:process',
      ],
    },
    target: 'node18',
    ssr: true,
  },
})
