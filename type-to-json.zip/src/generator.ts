import { resolve } from 'path'
import type { ParserContext, OutputMapping } from './types.js'
import { resolveTypeAliasProperties } from './parser.js'

function isFromInputFile(sourceFile: string, inputFile: string): boolean {
  return resolve(sourceFile) === resolve(inputFile)
}

/**
 * Generate JSON mapping only for exports declared in the input file.
 * Top-level keys use the exported type/interface name (e.g. IAuthLoginReq).
 */
export function generateMapping(ctx: ParserContext): OutputMapping {
  const output: OutputMapping = {}

  for (const [aliasName, alias] of ctx.typeAliases) {
    if (!isFromInputFile(alias.sourceFile, ctx.inputFile)) continue

    const properties = resolveTypeAliasProperties(aliasName, ctx)
    if (!properties || properties.length === 0) continue

    const displayName = aliasName
    const mapping: { [key: string]: string } = {}

    for (const prop of properties) {
      mapping[prop.name] = prop.name
    }

    output[displayName] = mapping
  }

  for (const [ifaceName, iface] of ctx.interfaces) {
    if (!isFromInputFile(iface.sourceFile, ctx.inputFile)) continue
    if (iface.properties.length === 0) continue

    const displayName = ifaceName
    const mapping: { [key: string]: string } = {}

    for (const prop of iface.properties) {
      mapping[prop.name] = prop.name
    }

    output[displayName] = mapping
  }

  return output
}

/**
 * Generate mapping for specific interfaces by name
 */
export function generateMappingForInterfaces(
  interfaceNames: string[],
  ctx: ParserContext,
): OutputMapping {
  const output: OutputMapping = {}

  for (const name of interfaceNames) {
    const iface = ctx.interfaces.get(name)
    if (!iface || iface.properties.length === 0) continue

    const displayName = name
    const mapping: { [key: string]: string } = {}

    for (const prop of iface.properties) {
      mapping[prop.name] = prop.name
    }

    output[displayName] = mapping
  }

  return output
}
